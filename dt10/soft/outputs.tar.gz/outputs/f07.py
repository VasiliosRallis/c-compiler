x=0

def main():
	global x
	x=1
	return (x)


# Boilerplat 
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
