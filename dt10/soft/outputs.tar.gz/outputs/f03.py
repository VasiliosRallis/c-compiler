def f(x):
	return (10)

def main():
	return (f)((11))+(7)


# Boilerplat 
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
