def main():
	z=0

	z=7
	return (z)


# Boilerplat 
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
