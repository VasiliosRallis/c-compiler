def main():
	return (1)*(2)+(3)*(4)+(5)*(6)+(7)*(8)


# Boilerplat 
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
