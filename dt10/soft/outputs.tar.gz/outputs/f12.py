def main():
	if(1):
		return (10)


	return (11)


# Boilerplat 
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
