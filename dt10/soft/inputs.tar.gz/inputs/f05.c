int main()
{
    int z;
    z=7;
    return z;
}

