int x;

int main()
{
    x=1;
    return x;
}

